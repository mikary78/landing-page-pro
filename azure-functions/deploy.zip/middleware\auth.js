"use strict";
/**
 * Microsoft Entra ID (Azure AD) JWT Token Verification Middleware
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.verifyToken = verifyToken;
exports.extractToken = extractToken;
exports.authenticateRequest = authenticateRequest;
exports.requireAuth = requireAuth;
const jwt = __importStar(require("jsonwebtoken"));
const jwksClient = __importStar(require("jwks-rsa"));
// JWKS Client 설정 (Microsoft Entra ID)
const client = new jwksClient.JwksClient({
    jwksUri: `https://login.microsoftonline.com/${process.env.ENTRA_TENANT_ID}/discovery/v2.0/keys`,
    cache: true,
    cacheMaxAge: 86400000, // 24 hours
});
/**
 * Get signing key from JWKS
 */
function getKey(header, callback) {
    client.getSigningKey(header.kid, (err, key) => {
        if (err) {
            callback(err);
            return;
        }
        const signingKey = key?.getPublicKey();
        callback(null, signingKey);
    });
}
/**
 * Verify JWT token
 */
async function verifyToken(token) {
    return new Promise((resolve, reject) => {
        jwt.verify(token, getKey, {
            audience: process.env.ENTRA_CLIENT_ID,
            issuer: `https://login.microsoftonline.com/${process.env.ENTRA_TENANT_ID}/v2.0`,
            algorithms: ['RS256'],
        }, (err, decoded) => {
            if (err) {
                reject(err);
            }
            else {
                resolve(decoded);
            }
        });
    });
}
/**
 * Extract token from Authorization header
 */
function extractToken(request) {
    const authHeader = request.headers.get('authorization');
    if (!authHeader) {
        return null;
    }
    const parts = authHeader.split(' ');
    if (parts.length !== 2 || parts[0] !== 'Bearer') {
        return null;
    }
    return parts[1];
}
/**
 * Authenticate request and extract user ID
 */
async function authenticateRequest(request, context) {
    try {
        const token = extractToken(request);
        if (!token) {
            context.log('[Auth] No token provided');
            return null;
        }
        const payload = await verifyToken(token);
        context.log('[Auth] Token verified successfully:', payload.oid);
        return {
            userId: payload.oid, // Azure AD Object ID
            email: payload.email || payload.preferred_username || '',
            name: payload.name || '',
        };
    }
    catch (error) {
        context.error('[Auth] Token verification failed:', error);
        return null;
    }
}
/**
 * Require authentication middleware
 */
async function requireAuth(request, context) {
    const user = await authenticateRequest(request, context);
    if (!user) {
        throw new Error('Unauthorized');
    }
    return user;
}
//# sourceMappingURL=auth.js.map