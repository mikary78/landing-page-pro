"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.hello = hello;
const functions_1 = require("@azure/functions");
async function hello(request, context) {
    context.log('HTTP trigger function processed a request.');
    const name = request.query.get('name') || await request.text() || 'world';
    return {
        status: 200,
        body: `Hello, ${name}!`
    };
}
functions_1.app.http('hello', {
    methods: ['GET', 'POST'],
    authLevel: 'anonymous',
    handler: hello
});
//# sourceMappingURL=hello.js.map