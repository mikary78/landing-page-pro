"use strict";
/**
 * Azure Functions Entry Point
 * Import all function modules to register them
 */
Object.defineProperty(exports, "__esModule", { value: true });
require("./functions/hello");
require("./functions/processDocument");
require("./functions/generateCurriculum");
//# sourceMappingURL=index.js.map